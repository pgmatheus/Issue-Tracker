'use strict';
const mongoose = require('mongoose');
mongoose.connect(process.env.DB_URI,{useNewUrlParser: true});

const User = new mongoose.Schema({
  issue_title: String,
  issue_text: String,
  duration: Number,
  created_by: String,
  assigned_to: String,
  status_text: String,
  open: Boolean,
  created_on: String, 
  updated_on: String,
  project: String
});

const user = mongoose.model('user', User);

module.exports = function (app) {

  app.route('/api/issues/:project')
  
    .get(function (req, res){      
      let project = req.params.project;
      let z = {project: project}
      
      let qq = req.query;
      if (qq!= undefined) {
        Object.assign(z, qq);
      }           
 
      user.find(z)
        .exec((err,doc1) => {
          if (err) console.log(err);
          if (doc1 == undefined){res.send('Not Ffound')}
          else{

            res.send(doc1)
          }

        })

    })
    
    .post(function (req, res){
      let project = req.body;
      console.log(project)
      let assig = "";
      let stats = "";
      let dat = new Date(Date.now());
      if (project.issue_title == undefined || project.created_by == undefined || project.issue_text == undefined) {
        res.send({error: 'required field(s) missing' })
      }
      else{
        if (project.assigned_to != undefined) {assig = project.assigned_to;}
        if (project.status_text != undefined) {stats = project.status_text}
        const a = new user({issue_title: project.issue_title,  issue_text: project.issue_text, created_by:   project.created_by, assigned_to: assig,   status_text: stats, open: true, created_on:  dat, updated_on: dat, project: req.params.project});
        a.save(function (err,doc1) {
          if (err) return handleError(err);
          res.send({assigned_to: doc1.assigned_to, status_text:   doc1.status_text, open: doc1.open, _id: doc1._id, 
          issue_title: doc1.issue_title, issue_text: doc1.issue_text,  created_by: doc1.created_by, created_on: doc1.created_on, updated_on:doc1.updated_on
          });  
       })      
      }


    })
    
    .put(function (req, res){
      let project = req.body;
      let test = ((project.issue_title == '' || project.issue_title == undefined) && (project.issue_text == '' || project.issue_text == undefined) && (project.created_by == '' || project.created_by == undefined) && (project.assigned_to == '' || project.assigned_to == undefined) && (project.status_text == '' || project.status_text == undefined))
 

      let dat = {updated_on: new Date(Date.now())};
      
      if (project._id == undefined){
        res.send({ error: 'missing _id' })
      }
      else if (test){
        res.send({ error: 'no update field(s) sent', _id: project._id })
      }
      else {
      let z = {_id: project._id}
      user.findOneAndUpdate(z,Object.assign(project, dat))
        .exec((err,doc) => {
          if (doc == undefined){
            res.send({ error: 'could not update', _id: project._id })
          }
          else{
            res.send({result: 'successfully updated', _id: project._id})
          }
        })        
      }
    })
    
    .delete(function (req, res){
      let project = req.body;
      console.log(req.body)
      if (project._id == undefined){console.log('Falta ID');res.send({ error: 'missing _id' })}
      else{
        user.findOneAndDelete({_id: project._id})
          .exec((err,doc) => {
            if (err) console.log(err)
            if (doc == undefined) {
            console.log('ID não encontrado');
            res.send({error: 'could not delete', _id: project._id})
            }
          else{
            console.log('Foi');
            res.send({result: 'successfully deleted', _id: project._id })
          }
        })
      }
    });
    
};
