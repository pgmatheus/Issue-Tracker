const chaiHttp = require('chai-http');
const chai = require('chai');
const assert = chai.assert;
const server = require('../server');
let id = 1;

chai.use(chaiHttp);

suite('Functional Tests', function() {
  this.timeout(5000);
  suite('Post Tests', function () {
      // 01
    test('Create an issue with every field: POST request', function (done) {
      chai
        .request(server)
        .post('/api/issues/projects')
        .set('content-type','application/json')
        .send({
          issue_title: 'issue_title',
          issue_text: 'issue_text',
          created_by: 'created_by',
          assigned_to: 'assigned_to',
          status_text: 'status_text'
         })
        .end(function(err,res) {
          assert.equal(res.body.issue_title,'issue_title');
          id = res.body._id;

          assert.equal(res.body.issue_text,'issue_text');
          assert.equal(res.body.created_by,'created_by');
          assert.equal(res.body.assigned_to,'assigned_to');
          assert.equal(res.body.status_text,'status_text');
          done();
        })
    })
      // 02
    test('Create an issue with only required fields: POST', function (done) {
      chai
        .request(server)
        .post('/api/issues/projects')
        .set('content-type','application/json')
        .send({
          issue_title: 'issue_title',
          issue_text: 'issue_text',
          created_by: 'created_by',
          assigned_to: '',
          status_text: ''
         })
        .end(function(err,res) {
          assert.equal(res.body.issue_title,'issue_title');
          assert.equal(res.body.issue_text,'issue_text');
          assert.equal(res.body.created_by,'created_by');
          assert.equal(res.body.assigned_to,'');
          assert.equal(res.body.status_text,'');
          done();
        })
    })   
      // 03
    test('Create an issue with missing required fields: POST', function (done) {
      chai
        .request(server)
        .post('/api/issues/projects')
        .set('content-type','application/json')
        .send({
          issue_title: undefined,
          issue_text: undefined,
          created_by: undefined,
          assigned_to: '',
          status_text: ''
         })
        .end(function(err,res) {       
          assert.equal(res.body.error,'required field(s) missing');
          done();
        })
    })
  })
  suite('Get Tests', function () {
      // 04
    test('View issues on a project: GET request to ', function (done) {
      chai
        .request(server)
        .get('/api/issues/projects')
        .end(function(err,res) {         
          assert.isAbove(res.body.length,1);
          done();
        })
    })
      // 05
    test('View issues on a project with one filter: GET', function (done) {
      chai
        .request(server)
        .get('/api/issues/projects')
        .send({issue_title: 'issue_title'})
        .end(function(err,res) {         
          assert.isAbove(res.body.length,1);
          done();
        })
    })
      // 06
    test('View issues on a project with multiple filters: GET', function (done) {
      chai
        .request(server)
        .get('/api/issues/projects')
        .send({issue_title: 'issue_title',issue_text: 'issue_text'})
        .end(function(err,res) { 
          assert.isAbove(res.body.length,1);
          done();
        })
    })  
  })
  suite('Put Tests', function () {  
      // 07
    test('Update one field on an issue: PUT', function (done) {
      chai
        .request(server)
        .put('/api/issues/projects')
        .send({issue_title: 'issue_titlem',_id: id})
        .end(function(err,res) {
          console.log(res.body.result) 
          assert.equal(res.body.result,'successfully updated');
          done();
        })
    }) 
      // 08
    test('Update multiple fields on an issue: PUT', function (done) {
      chai
        .request(server)
        .put('/api/issues/projects')
        .send({issue_title: 'issue_titlem',_id: id,issue_text: 'undefined'})
        .end(function(err,res) {
          assert.equal(res.body.result,'successfully updated');
          done();
        })
    }) 
      // 09
    test('Update multiple fields on an issue: PUT', function (done) {
      chai
        .request(server)
        .put('/api/issues/projects')
        .send({_id: undefined})
        .end(function(err,res) {
          assert.equal(res.body.error,'missing _id');
          done();
        })
    }) 
      // 10
    test('Update an issue with no fields to update: PUT', function (done) {
      chai
        .request(server)
        .put('/api/issues/projects')
        .send({_id: id})
        .end(function(err,res) {
          assert.equal(res.body.error,'no update field(s) sent');
          done();
        })
    }) 
      // 11
    test('Update an issue with an invalid _id', function (done) {
      chai
        .request(server)
        .put('/api/issues/projects')
        .send({issue_title: 'issue_titlem', _id: 11})
        .end(function(err,res) {
          assert.equal(res.body.error,'could not update');
          done();
        })
    })
  })
  suite('Put Delete', function () {  
      // 12
    test('Delete an issue: DELETE', function (done) {
      chai
        .request(server)
        .delete('/api/issues/projects')
        .send({_id: id})
        .end(function(err,res) {
          assert.equal(res.body.result,'successfully deleted');
          done();
        })
    })
      // 13   
    test('Delete an issue: DELETE', function (done) {
      chai
        .request(server)
        .delete('/api/issues/projects')
        .send({_id: 11})
        .end(function(err,res) {
          assert.equal(res.body.error,'could not delete');
          done();
        })
    })
      // 14   
    test('Delete an issue with missing _id: DELETE', function (done) {
      chai
        .request(server)
        .delete('/api/issues/projects')
        .send({_id: undefined})
        .end(function(err,res) {
          assert.equal(res.body.error,'missing _id');
          done();
        })
    })



    
  })
})









